const { spawn } = require('child_process');
const path = require('path');

exports.handler = async (event, context) => {
  console.log('Function called:', event.path, event.httpMethod);
  
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS'
      },
      body: ''
    };
  }

  // Parse the path to get the endpoint
  const pathParts = event.path.split('/');
  const endpoint = pathParts.slice(-1)[0] || pathParts.slice(-2)[0];
  
  try {
    // Simple endpoint routing
    if (endpoint === 'health') {
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
          status: 'healthy',
          service: 'adk-agent',
          timestamp: new Date().toISOString(),
          message: 'ADK Agent service is running (JS wrapper)'
        })
      };
    }
    
    if (endpoint === 'status') {
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
          status: 'active',
          agent_type: 'core_agent',
          capabilities: ['chat', 'analysis'],
          backend: 'netlify-functions-js'
        })
      };
    }
    
    if (event.path.includes('/v1/agent/run') && event.httpMethod === 'POST') {
      const requestBody = JSON.parse(event.body || '{}');
      const message = requestBody.message || 'Hello from ADK agent!';
      
      // Mock response since we're testing connectivity
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
          response: `ADK Agent received: "${message}". This is a test response from the Netlify function.`,
          status: 'success',
          agent: 'adk-core',
          timestamp: new Date().toISOString()
        })
      };
    }
    
    // Default 404 for unknown endpoints
    return {
      statusCode: 404,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        error: 'Endpoint not found',
        path: event.path,
        available_endpoints: ['/health', '/status', '/v1/agent/run']
      })
    };
    
  } catch (error) {
    console.error('Function error:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message
      })
    };
  }
}; 